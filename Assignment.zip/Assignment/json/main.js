$(document).ready(function() {
	var data = {
		result: [
			{
				title: 'Product 1',
				qty: null,
				price: null,
				total: 3877410,
				level: 1,
				children: [
					{
						title: 'Sub Product 1',
						qty: null,
						price: null,
						total: 3784812,
						level: 2,
						children: [
							{
								title: 'dummy text 1',
								qty: 11,
								price: 3,
								total: 33,
								level: 3
							},
							{
								title: 'dummy text 2',
								qty: 12,
								price: 4,
								total: 48,
								level: 3
							}
						]
					},
					{
						title: 'Sub Product 2',
						qty: null,
						price: null,
						total: 92598,
						level: 2,
						children: [
							{
								title: 'dummy text 7',
								qty: 17,
								price: 9,
								total: 153,
								level: 3
							},
							{
								title: 'dummy text 8',
								qty: 18,
								price: 10,
								total: 180,
								level: 3
							},
							{
								title: 'dummy text 19',
								qty: 29,
								price: 21,
								total: 609,
								level: 3
							},
							{
								title: 'dummy text 176',
								qty: 186,
								price: 178,
								total: 33108,
								level: 3
							},
							{
								title: 'dummy text 236',
								qty: 246,
								price: 238,
								total: 58548,
								level: 3
							}
						]
					}
				]
			},
			{
				title: 'Product 4',
				qty: null,
				price: null,
				total: 773998,
				level: 1,
				children: [
					{
						title: 'Sub Product 6',
						qty: null,
						price: null,
						total: 767829,
						level: 2,
						children: [
							{
								title: 'dummy text 5',
								qty: 15,
								price: 7,
								total: 105,
								level: 3
							},
							{
								title: 'dummy text 6',
								qty: 16,
								price: 8,
								total: 128,
								level: 3
							}
						]
					},
					{
						title: 'Sub Product 12',
						qty: null,
						price: null,
						total: 6169,
						level: 2,
						children: [
							{
								title: 'dummy text 9',
								qty: 19,
								price: 11,
								total: 209,
								level: 3
							},
							{
								title: 'dummy text 10',
								qty: 20,
								price: 12,
								total: 240,
								level: 3
							},
							{
								title: 'dummy text 11',
								qty: 21,
								price: 13,
								total: 273,
								level: 3
							},
							{
								title: 'dummy text 12',
								qty: 22,
								price: 14,
								total: 308,
								level: 3
							},
							{
								title: 'dummy text 13',
								qty: 23,
								price: 15,
								total: 345,
								level: 3
							}
						]
					}
				]
			},
			{
				title: 'Product 2',
				qty: null,
				price: null,
				total: 1940774,
				level: 1,
				children: [
					{
						title: 'Sub Product 3',
						qty: null,
						price: null,
						total: 1940774,
						level: 2,
						children: [
							{
								title: 'dummy text 37',
								qty: 47,
								price: 39,
								total: 1833,
								level: 3
							},
							{
								title: 'dummy text 50',
								qty: 60,
								price: 52,
								total: 3120,
								level: 3
							},
							{
								title: 'dummy text 51',
								qty: 61,
								price: 53,
								total: 3233,
								level: 3
							}
						]
					}
				]
			},
			{
				title: 'Product 8',
				qty: null,
				price: null,
				total: 154450109,
				level: 1,
				children: [
					{
						title: 'Sub Product 11',
						qty: null,
						price: null,
						total: 154450109,
						level: 2,
						children: [
							{
								title: 'dummy text 38',
								qty: 48,
								price: 40,
								total: 1920,
								level: 3
							},
							{
								title: 'dummy text 73',
								qty: 83,
								price: 75,
								total: 6225,
								level: 3
							},
							{
								title: 'dummy text 225',
								qty: 235,
								price: 227,
								total: 53345,
								level: 3
							}
						]
					}
				]
			},
			{
				title: '',
				qty: null,
				price: null,
				total: 498939,
				level: 1,
				children: [
					{
						title: 'Sub Product 13',
						qty: null,
						price: null,
						total: 498939,
						level: 2,
						children: [
							{
								title: 'dummy text 258',
								qty: 268,
								price: 260,
								total: 69680,
								level: 3
							},
							{
								title: 'dummy text 259',
								qty: 269,
								price: 261,
								total: 70209,
								level: 3
							}
						]
					}
				]
			}
		]
	};

	var thirdLevelData = [];
	var secondLevelData = [];
	var firstName = (secondName = '');
	var tableStr = '';
    var producttitle = (thirdproductName = '');
  
	_.forEach(data.result, function(item, index) {
		tableStr += '<tr data-tt-id="' + index + '">';
		tableStr += '<td>' + item.title + '</td>';
		tableStr += '</tr>';
		
		
		firstName = item.title;
		producttitle = item.title;
		
		
		_.forEach(item.children, function(secondLevel, secondIndex, thirdproductName) {
			
				  
					
			tableStr += '<tr data-tt-id="' + index + '-' + secondIndex + '" data-tt-parent-id="' + index + '">';
			tableStr += '<td>' + secondLevel.title + '</td>';
			
			tableStr += '</tr>';
			
 
		   
		
			secondName = secondLevel.title;
			secondLevelData.push(secondLevel);
			
			_.forEach(secondLevel.children, function(thirdLevel, thirdIndex) {
				
			
				tableStr +=
					'<tr data-tt-id="' +
					index +
					'-' +
					secondIndex +
					'-' +
					thirdIndex +
					'" data-tt-parent-id="' +
					index +
					'-' +
					secondIndex +
					'">';
					
				 
				
				tableStr += '<td>' + thirdLevel.title + '</td>';
				tableStr += '<td>' + thirdLevel.qty + '</td>';
				tableStr += '<td>' + thirdLevel.price + '</td>';
				tableStr += '<td>' + thirdLevel.total + '</td>';
				tableStr += '</tr>';
				if (thirdLevel != null) {
					thirdLevelData.push({
						title: thirdLevel.title,
						qty: thirdLevel.qty,
						price: thirdLevel.price,
						total: thirdLevel.total,
						parent: secondName,
						superParent: firstName
					});
				}
			});
			console.log('second level complete');
		});
	});
	var html = '';
	$.each(thirdLevelData, function(key, value) {
		html += '<tr data-tt-id="' + key + '">';
		html += '<td class="col-3">' + value.title + '</td>';
		html += '<td class="col-3">' + value.qty + '</td>';
		html += '<td class="col-2">' + value.price + '</td>';
		html += '<td class="col-2">' + value.total + '</td>';
		html += '<td class="col-2">' + value.parent + '</td>';
		html += '</tr>';
	});
	$('#firstTbl tbody').html(html);
	var html2 = '';
	$.each(secondLevelData, function(key, value) {
		html2 += '<tr>';
		html2 += '<td class="col-3" data-tt-id="' + key + '">' + value.title + '</td>';
		html2 += '<td class="col-3">' + value.qty + '</td>';
		html2 += '<td class="col-2">' + value.price + '</td>';
		html2 += '<td class="col-2">' + value.total + '</td>';
		html2 += '<td class="col-2">' + value.level + '</td>';
		html2 += '</tr>';
	});
	$('.secondLevel tbody').html(html2);

	var dataforpie = _.map(secondLevelData, function(item) {
		return {
			name: item.title,
			y: item.total
		};
	});

	$('#treeData').html(tableStr);
	console.log(dataforpie);
	$('#treeData').treetable({ expandable: true });

	$('#treeData tr').click(function() {
		if (!$(this).is('.expanded')) {
			$('#treeData').treetable('expandNode', $(this).data('ttId'));
		} else {
			$('#treeData').treetable('collapseNode', $(this).data('ttId'));
		}
	});

	Highcharts.chart('container', {
		chart: {
			plotBackgroundColor: null,
			plotBorderWidth: null,
			plotShadow: false,
			type: 'pie'
		},
		title: {
			text: 'Level 2 Products'
		},
		tooltip: {
			pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
		},
		plotOptions: {
			pie: {
				allowPointSelect: true,
				cursor: 'pointer',
				dataLabels: {
					enabled: true,
					format: '<b>{point.name}</b>: {point.percentage:.1f} %'
				}
			}
		},
		series: [
			{
				name: 'Brands',
				colorByPoint: true,
				data: dataforpie
			}
		]
	});
});

function activateTree() {
	$('#treeData').treetable('expandNode', '0second');
}
